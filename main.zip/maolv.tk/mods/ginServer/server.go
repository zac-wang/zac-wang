package ginServer

import (
	"context"
	"errors"
	"fmt"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"
)

var GinEngine = gin.Default()
var srv *http.Server

// Run 启动http服务，配合FreeServerPort使用
func Run(addr string) *http.Server {
	return runCallBack(addr, func(server *http.Server) (err error) {
		return srv.ListenAndServe()
	})
}

// RunTLS 启动http服务，配合FreeServerPort使用
func RunTLS(addr, certFile, keyFile string) *http.Server {
	return runCallBack(addr, func(server *http.Server) (err error) {
		return srv.ListenAndServeTLS(certFile, keyFile)
	})
}

func runCallBack(addr string, startServerFun func(server *http.Server) (err error)) *http.Server {
	freeServerPort(srv)

	srv = &http.Server{
		Addr:    addr,
		Handler: GinEngine,
		//ReadHeaderTimeout: 5 * time.Second,
		//WriteTimeout:      5 * time.Second,
	}

	srv.RegisterOnShutdown(func() {
		fmt.Printf("%s ==> :%s HTTP服务关闭\n", time.Now().Format("2006-01-02 15:04:05"), addr)
	})

	go func(srv *http.Server) (err error) {
		err = startServerFun(srv)
		if err != nil && errors.Is(err, syscall.EADDRINUSE) {
			println("端口被占用，启动失败")
			os.Exit(0)
		}
		return err
	}(srv)

	watch()

	return srv
}

// FreeServerPort 取消服务
func freeServerPort(srv *http.Server) (err error) {
	if srv == nil {
		return nil
	}
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err = srv.Shutdown(ctx /*context.TODO()*/); err != nil {
		panic(err)
	}
	srv = nil
	return err
}

var isFirstStartServer bool

func watch() {
	if !isFirstStartServer {
		isFirstStartServer = true

		ch := make(chan os.Signal, 1)
		signal.Notify(ch, syscall.SIGHUP, syscall.SIGINT, syscall.SIGTERM, syscall.SIGQUIT, syscall.SIGUSR1, syscall.SIGUSR2)
		s := <-ch
		close(ch)
		log.Println("接收到信号", s.String(), "执行关闭函数")
	}
}
