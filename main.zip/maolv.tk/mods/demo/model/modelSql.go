package model

import (
	"time"
)

type TImUsers struct {
	//gorm.Model
	ID        uint      `gorm:"primarykey"`
	CreatedAt time.Time `json:"omitempty"`
	UpdatedAt time.Time `json:"omitempty"`
	DeletedAt time.Time `json:"omitempty"`

	Name     string `gorm:"index:user;unique;not null;comment:用户名" json:"name"` // 给Name字段创建名为user的索引, 设置用户名（Name）唯一并且不为空
	Password string `gorm:"comment:密码" json:"pwd"`
	Mark     string `gorm:"comment:备注" json:"mark,omitempty"` // omitempty：如果为空置则忽略字段
	Ignore   string `json:"-"`                                // 直接忽略字段
}

type User struct {
	ID     uint   `gorm:"unique_index;primary_key;AUTO_INCREMENT"`   // 唯一索引，主键，自增
	User   string `gorm:"index:user"`                                // 创建索引并命名user，如果有其他同名索引，则创建组合索引
	Phone  string `gorm:"unique;not null" json:"phone"`              // 唯一并且不为空
	Email  string `gorm:"column:mail;type:varchar(30)" json:"email"` // 设置列名;类型
	Mark   string `gorm:"comment:备注" json:"mark"`                    // 设置注释
	Remark string `gorm:"default:''"`                                //默认值

	TImUsers TImUsers `gorm:"embedded;embeddedPrefix:author_"` //嵌套字段,嵌入字段的列名前缀

	Name0 string `gorm:"<-"`                 // 允许读写（创建和更新）
	Name1 string `gorm:"<-:create"`          // 允许读和创建
	Name2 string `gorm:"<-:update"`          // 允许读和更新
	Name3 string `gorm:"<-:false"`           // 允许读 ，不允许写
	Name4 string `gorm:"->"`                 // 只读（除非有别的特殊配置不然就是禁用写）
	Name5 string `gorm:"->;<-:create"`       // 允许读和创建
	Name6 string `gorm:"->:false;<-:create"` // 只是创建（禁用从数据库的读取权限）

	Name7 string `gorm:"-"`           // 在结构体读写时忽略此字段
	Name8 string `gorm:"-:all"`       // 在结构体读写、甚至是迁移表时忽略此字段
	Name9 string `gorm:"-:migration"` // 在结构体迁移表时忽略该字段
}

func (User) TableName() string {
	return "User"
}
