package controller

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/config"
	zcpath "github.com/zac-wang/utils/path"
	"github.com/zac-wang/utils/request"
	"path"
	"time"
)

type FileInfo struct {
	Ext  string `form:"ext" json:"ext" binding:"required"`
	Time string `form:"time" json:"time" binding:"required"`
}

func Files(c *gin.Context) {
	// 参数绑定（get：query，post：content-type => json, Form => form-data）
	var fl FileInfo
	err := c.ShouldBind(&fl)
	fmt.Println(fl)

	files, err := zcpath.GetAllFilePaths("tmp", zcpath.GetFilePathsIgnoreDirCallBack)
	if err != nil {
		panic(err)
	}
	request.Success(c, files, "")
}

func FileGet(c *gin.Context) {
	// m := c.GetString("ok")    // 获取post(json)参数
	// m,_ := c.GetQuery("ok")   // 获取url路径后参数
	name := c.Param("name") // 获取url路径内参数
	//name, err := url.QueryUnescape(name)

	saveFilePath := config.ServerViper.GetString("tmpFilePath")
	c.File(path.Join(saveFilePath, name))
}

func FilePost(c *gin.Context) {
	saveFilePath := config.ServerViper.GetString("tmpFilePath")

	/*
		if c.Param("name") == "single" {
			//单个文件上传
			file, err := c.FormFile("f1")
			if err == nil {
				saveName := getFileName(file.Filename)
				dst := path.Join(saveFilePath, saveName)
				if err = c.SaveUploadedFile(file, dst); err == nil {
					request.Success(c, "", "上传成功")
					return
				}
			}
		}
	*/
	//多个文件上传
	form, err := c.MultipartForm()
	if err == nil {
		files := form.File["f1"]
		var fileList []string
		for index, file := range files {
			saveName := fmt.Sprintf("%s-%d%s", getFileName(file.Filename), index, path.Ext(file.Filename))
			dst := path.Join(saveFilePath, saveName)
			if err = c.SaveUploadedFile(file, dst); err == nil {
				fileList = append(fileList, saveName)
			}
		}
		request.Success(c, fileList, "上传成功")
		return
	}

	request.Fail(c, "", "上传失败"+err.Error())
}

func getFileName(defaultName string) string {
	if len(defaultName) <= 0 {
		defaultName = time.Now().String()
	}
	return defaultName
}
