package controller

import (
	"encoding/base64"
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/demo/model"
	"github.com/zac-wang/utils/request"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"math/rand"
	"strconv"
)

type ImUserList []model.TImUsers

// 分页查询
func selectPageDB(page, pageSize int) (total int64, us *ImUserList, err error) {
	db, err := gorm.Open(sqlite.Open("tmp/im.sqlite"), &gorm.Config{})
	if err != nil {
		panic("failed to connect database")
	}

	db = db.Table("IMUsers")
	db.AutoMigrate(&model.TImUsers{})
	if err := db.Count(&total).Error; err != nil {
		return 0, nil, err
	}

	if total < 20 {
		for i := 0; i < 100; i++ {
			db.Create(&model.TImUsers{Name: base64.StdEncoding.EncodeToString([]byte(strconv.Itoa(int(rand.Int63()))))[:9], Password: base64.StdEncoding.EncodeToString([]byte(strconv.Itoa(int(rand.Int63()))))[:9], Mark: "备注"})
		}
	}

	us = new(ImUserList)
	if err := db.Select("ID,name,password").Order("id DESC").Limit(pageSize).Offset(page * pageSize).Find(&us).Error; err != nil {
		return total, nil, err
	}
	return total, us, nil
}

func SelectOrder(c *gin.Context) {
	page, _ := strconv.Atoi(c.DefaultQuery("page", "0"))
	pageSize, _ := strconv.Atoi(c.DefaultQuery("pageSize", "10"))
	total, us, err := selectPageDB(page, pageSize)
	if err != nil {
		request.Fail(c, nil, "查询数据异常")
	} else {
		request.Success(c, &us, "", map[string]any{"total": total})
	}
}
