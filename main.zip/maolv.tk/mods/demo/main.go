package demo

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/demo/controller"
)

func RegisterApiUrl(r *gin.Engine) {
	sDemo := r.Group("/v1/simple")
	{
		sDemo.GET("/files", controller.Files)
		sDemo.GET("/file/*name", controller.FileGet) // 泛绑定
		sDemo.POST("/file/:name", controller.FilePost)
		sDemo.GET("/reqSqlPage", controller.SelectOrder)
	}
}
