package adapt

import (
	"fmt"
	"github.com/mattn/go-sqlite3"
	"github.com/zac-wang/demo/model"
	"gorm.io/gorm"
	"strings"
)

// 创建记录
func insertDB(db *gorm.DB, u string, p string) {
	recode := model.TImUsers{Name: u, Password: p, Mark: "备注"}
	err := db.Create(&recode).Error //.RowsAffected // 返回插入的记录数
	if err != nil {
		fmt.Printf("%s\n", err.Error())
		if err.(sqlite3.Error).ExtendedCode == 2067 { // 唯一字段冲突，数据重复
			msg := string(err.Error())
			if strings.HasSuffix(msg, ".Name") {
				fmt.Printf("用户%v已存在", recode.Name)
			}
		}
	}
}

func deleteDB(db *gorm.DB, name string) {
	// 软删除
	//db.Delete(&u)
	//db.Delete(&u, 10) //按primary key去删除 // DELETE FROM users WHERE id = 10;
	//db.Delete(&u, []int{1,2,3}) //按primary key去删除 // DELETE FROM users WHERE id IN (1,2,3);
	db.Where("Name = ?", name).Delete(&model.TImUsers{})
}

// 更新
func updateDB(db *gorm.DB, u *model.TImUsers) {
	db.Model(&u).Update("Name", "LiSi")
	// 更新多条字段数据
	//db.Model(&u).Updates(sqlModel.TImUsers{Name: "ZhaoWu", Mark: "5"}) // non-zero fields
	//db.Model(&u).Updates(map[string]interface{}{"Name": "ZhaoWu", "Mark": "6"})
}

// 查询
func selectDB(db *gorm.DB, name string) (catU *model.TImUsers, err error) {
	// 1、查询一条数据
	catU = new(model.TImUsers)
	err = db.First(catU).Error //查询表中第一行的数据

	// 2、查询多条数据
	//catU = new([]model.TImUsers)
	//err = db.Find(&catU, "Name = ?", name).Error
	//fmt.Printf("%#v\n", catU)

	// 3、查询被软删除的数据
	//d := model.TImUsers{}
	//err = db.Unscoped().Where("Name = ?", "LiSi").Find(&d).Error // 使用Unscoped()查询软删除的数据(包括删除时间)
	//fmt.Printf("%#v\n", d)

	//if err != nil { return nil, err }
	return catU, err
}

/*
func oldSelect(user string) (pwd string) {
	sqlDB, err := sql.Open(config.ImViper.GetString("tim.sqlType"), config.ImViper.GetString("tim.sqlPath"))
	if err != nil {
		return ""
	}

	result := sqlDB.QueryRow(`select * from "IMUsers" WHERE "name" = $1`, user)
	if err != nil {
		return ""
	}

	var id, name, password, score string
	result.Scan(&id, &name, &password, &score)
	return password
}
*/

func Operate() {
	//insertDB(demoSql, "ZhangSan", "mima")
	catU, _ := selectDB(DemoSql(), "ZhangSan")
	updateDB(DemoSql(), catU)
	deleteDB(DemoSql(), "LiSi")
}

func Handle() {
	config()
	Operate()
}
