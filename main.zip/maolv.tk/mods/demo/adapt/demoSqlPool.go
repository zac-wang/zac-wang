package adapt

import (
	"errors"
	"github.com/zac-wang/demo/model"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
	"gorm.io/gorm/schema"
	"net/url"
	"time"
)

var demoSql *gorm.DB

func DemoSql() *gorm.DB {
	if demoSql == nil {
		demoSql = getDemoSql()
	}
	return demoSql
}

// 参考：Go语言中号称最友好的ORM之GROM详解篇 https://mp.weixin.qq.com/s?__biz=MjM5NTIxNjAwNQ==&mid=2448099784&idx=1&sn=e1a50d7cf4f5b5931b8c373c8b9c5e71&chksm=b2e446228593cf341f639ea22d06d658ba918c1994e8e8cdbecc384f4fcca20c0e5e4e469260&scene=21#wechat_redirect

func getDemoSql() (db *gorm.DB) {
	db, err := gorm.Open(sqlite.Open("im.sqlite"), &gorm.Config{
		NamingStrategy: schema.NamingStrategy{
			SingularTable: true, // 默认生成的表名结尾不自动加s
		},
	})
	if err != nil {
		panic(errors.New("连接数据库失败"))
	}
	//db = db.Set("gorm:table_options", "ENGINE=InnoDB DEFAULT CHARSET=utf8")
	//db = db.Table("IMUsers") // 指定表名，默认根据类名生成一个下划线命名

	// 在数据库中创建对应的TImUsers表
	db.AutoMigrate(&model.User{})
	if err != nil {
		println(err)
	}

	sqlDB, _ := db.DB()
	sqlDB.SetMaxOpenConns(100)                 // 设置数据库连接池最大连接数
	sqlDB.SetMaxIdleConns(20)                  // 设置最大允许的闲置连接数
	sqlDB.SetConnMaxLifetime(time.Hour)        // 设置连接可复用的最大时间
	sqlDB.SetConnMaxIdleTime(10 * time.Minute) // 设置连接最大闲置时间，超出将被释放
	//defer sqlDB.Close()
	return db
}

func config() {
	// 禁用默认表名的复数形式，如果置为 true，则 `User` 的默认表名是 `user`
	//db.SingularTable(true)
	//GORM还支持更改默认表名称规则
	//gorm.DefaultTableNameHandler = func(db *gorm.DB, defaultTableName string) string {
	//	return "xxx_" + defaultTableName
	//}
}

func sqlserverStr() string {
	query := url.Values{}
	query.Add("database", "NW_ZJK")
	query.Add("encrypt", "disable")
	u := &url.URL{
		Scheme:   "sqlserver",
		User:     url.UserPassword("tyw_test", "Tyw@789"),
		Host:     "192.168.1.189:1433",
		RawQuery: query.Encode(),
	}
	//fmt.Println(u.String())
	//db, err := gorm.Open("mssql", "sqlserver://username:password@localhost:1433?database=dbname")
	return u.String()
}
