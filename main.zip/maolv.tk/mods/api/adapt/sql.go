package adapt

import (
	"github.com/zac-wang/api/model"
	"github.com/zac-wang/config"
	"gorm.io/driver/sqlite"
	"gorm.io/gorm"
)

var imsql *gorm.DB

func IMSql() *gorm.DB {
	if imsql == nil {
		imsql = getSql()
	}
	return imsql
}

func getSql() *gorm.DB {
	sqlPath := config.ImViper.GetString("tim.sqlPath")
	db, err := gorm.Open(sqlite.Open(sqlPath), &gorm.Config{})
	if err != nil {
		panic("failed to connect database")
	}
	initTables(db)
	return db
}

func initTables(db *gorm.DB) {
	err := db.AutoMigrate(
		model.TImUsers{},
		//model.TImCommands{},
		//model.TIMAppHandles{},
	)
	if err != nil {
		println(err)
	}
}
