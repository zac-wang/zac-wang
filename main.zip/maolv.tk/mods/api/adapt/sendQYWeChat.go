package adapt

import (
	"github.com/zac-wang/config"
	"github.com/zac-wang/utils/json"
	"github.com/zac-wang/utils/request"
	"log"
)

func QiyeGetToken() (token string) {
	tokenUrl := "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=" + config.ImViper.GetString("qiYeWeChat.corpid") + "&corpsecret=" + config.ImViper.GetString("qiYeWeChat.corpsecret")
	body := request.HTTPGet(tokenUrl)
	data := json.JsonForByte(body).(map[string]any)
	if data["access_token"] != nil {
		return data["access_token"].(string)
	}
	return ""
}

func QiyeIMSend(msg string, toUsers ...string) {
	toUser := "WangZhiChao"
	if len(toUsers) > 0 {
		toUser = toUsers[0]
	}

	data := map[string]any{"touser": toUser, //"@all", //"WangZhiChao|000002",
		//"toparty" : "PartyID1|PartyID2",
		//"totag" : "TagID1 | TagID2",
		"msgtype": "text",
		"agentid": 1000002,
		"text": map[string]string{
			"content": msg,
		},
		"safe":                   0,
		"enable_id_trans":        0,
		"enable_duplicate_check": 0,
	}

	resp := request.HTTPPost(config.ImViper.GetString("qiYeWeChat.sentIMUrl")+QiyeGetToken(), data)
	log.Print(string(resp))
}
