package adapt

import (
	"github.com/zac-wang/config"
	"github.com/zac-wang/tencentIM"
	"github.com/zac-wang/utils/json"
	"github.com/zac-wang/utils/request"
	"log"
	"math/rand"
	"strconv"
	"time"
)

// 更多api参见 即时通信IM: [REST API 接口列表](https://cloud.tencent.com/document/product/269/1520)
const sendUrl = "https://console.tim.qq.com/v4/openim/sendmsg?sdkappid=1400375758&contenttype=json&identifier="

// TIMSend 发送腾讯IM信息
func TIMSend(msg string, isCmd bool, toUsers ...string) {
	toUser := "root"
	if len(toUsers) > 0 {
		toUser = toUsers[0]
	}

	formUser := "root"
	sign, err := tencentIM.GenUserSig(config.ImViper.GetInt("tim.sdkAppid"), config.ImViper.GetString("tim.imKey"), formUser, config.ImViper.GetInt("tim.timeout"))
	if err != nil {
		log.Print(err.Error())
		return
	}

	url := sendUrl + formUser + "&usersig=" + sign + "&random=" + strconv.FormatInt(rand.Int63n(4294967295), 10)
	var body []any
	body = append(body, map[string]any{
		"MsgType": "TIMTextElem",
		"MsgContent": map[string]any{
			"Text": msg,
			"info": "",
		},
	})
	if isCmd {
		data := map[string]any{"isCommand": true, "command": msg}
		body = append(body, map[string]any{
			"MsgType": "TIMCustomElem",
			"MsgContent": map[string]any{
				"Data": string(json.FormatJson(data)),
				//"Desc":  "notification",  // 离线推送文本展示(OfflinePushInfo.Desc优先)
				//"Ext":   "url",           // iOS APNs 请求包 Payloads 中的 Ext 键值
				//"Sound": "dingdong.aiff", // 推送铃音
			},
		})
	}
	data := map[string]any{
		"SyncOtherMachine": 1, // 消息同步至发送方
		"From_Account":     formUser,
		"To_Account":       toUser,
		"MsgRandom":        rand.Int63n(4294967295), // 随机数(32位无符号整数)
		"MsgTimeStamp":     time.Now().Unix(),       // 时间戳
		"MsgBody":          body,
		"CloudCustomData":  "your cloud custom data",
	}
	resp := request.HTTPPost(url, data)
	log.Print(string(resp))
}
