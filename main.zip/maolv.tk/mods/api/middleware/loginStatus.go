package middleware

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/config"
	"github.com/zac-wang/tencentIM"
	"github.com/zac-wang/utils/request"
	"time"
)

// CheckLoginStatus 登录验证
func CheckLoginStatus(c *gin.Context) {
	name, _ := c.Cookie("user")
	sign, _ := c.Cookie("sign")
	c.Set("user", name) // 与其他中间件共享数据

	if len(name) <= 0 || len(sign) <= 0 || tencentIM.VerifyUserSig(uint64(config.ImViper.GetInt64("tim.sdkAppid")), config.ImViper.GetString("tim.imKey"), name, sign, time.Now()) != nil {
		c.Abort()
		request.Fail(c, nil, "请检查登录状态")
	} else {
		c.Next()
	}
}
