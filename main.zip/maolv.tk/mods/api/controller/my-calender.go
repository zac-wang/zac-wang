package controller

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/zac-wang/utils/request"
)

func GetCalenderFile(c *gin.Context) {
	sign, ok := c.GetQuery("sign")

	if ok && sign == "6EA9A49A-053E-403F-8706-961F4D72BDCF" { // 命令uuidgen随机生成
		c.String(http.StatusOK, "214123541")
	} else {
		request.Success(c, nil, "成功")
	}
}
