package controller

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/utils/json"
	"log"
	"net/http"
)

// / 账号状态发生变化
func stateChange(c *gin.Context, data map[string]any) {
	info := data["Info"].(map[string]any)
	if info["Action"] == "Login" {
		fmt.Println(info["To_Account"].(string) + "上线")
	} else if info["Action"] == "Disconnect" {
		fmt.Println(info["To_Account"].(string) + "掉线")
	}
}

// / 消息发送前
func beforeSendMsg(c *gin.Context, data map[string]any) {
	fmt.Printf("%s 发送至 %s\n", data["From_Account"], data["To_Account"])
	fmt.Println(string(json.FormatJson(data["MsgBody"])))
}

// / 消息发送后
func afterSendMsg(c *gin.Context, data map[string]any) {
}

func ServiceCallback(c *gin.Context) {
	if m, _ := c.GetQuery("contenttype"); m == "json" {
		body, _ := c.GetRawData()
		data := json.JsonForByte(body).(map[string]any)
		log.Println(string(body))

		command, _ := c.GetQuery("CallbackCommand")
		if command == "State.StateChange" {
			stateChange(c, data)
		} else if command == "C2C.CallbackBeforeSendMsg" {
			beforeSendMsg(c, data)
		} else if command == "C2C.CallbackAfterSendMsg" {
			afterSendMsg(c, data)
		}
	}

	result := map[string]any{
		"ActionStatus": "OK", // 必填: OK 表示处理成功，FAIL 表示失败
		"ErrorCode":    0,    // 必填: 0为回调成功，1为回调出错
		"ErrorInfo":    "数据处理完成",
	}
	c.JSON(http.StatusOK, result)
}
