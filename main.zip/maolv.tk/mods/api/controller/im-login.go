package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/api/adapt"
	"github.com/zac-wang/api/model"
	"github.com/zac-wang/config"
	"github.com/zac-wang/tencentIM"
	"github.com/zac-wang/utils/json"
	"github.com/zac-wang/utils/request"
)

func verifyUserInfo(user string, pwd string) bool {
	db := adapt.IMSql()
	catU := new(model.TImUsers)
	if err := db.Find(&catU, "Name = ?", user).Error; err != nil {
		return false
	}
	return catU.Password == pwd
}

func Login(c *gin.Context) {
	body, _ := c.GetRawData()
	data := json.JsonForByte(body).(map[string]any)

	user := data["name"].(string)
	pwd := data["password"].(string)

	if verifyUserInfo(user, pwd) {
		sign, err := tencentIM.GenUserSig(config.ImViper.GetInt("tim.sdkAppid"), config.ImViper.GetString("tim.imKey"), user, config.ImViper.GetInt("tim.timeout"))
		if err != nil {
			request.Fail(c, nil, err.Error())
		} else {
			result := map[string]any{"user": user}
			result["sign"] = sign
			result["tokenEffectiveDuration"] = config.ImViper.GetInt("tim.timeout")
			request.CookieWrite(c, "user", user, config.ImViper.GetInt("tim.timeout"))
			request.CookieWrite(c, "sign", sign, config.ImViper.GetInt("tim.timeout"))
			request.Success(c, result, "")
		}
	} else {
		request.Fail(c, nil, "账号密码错误")
	}
}
