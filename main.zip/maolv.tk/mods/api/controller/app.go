package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/utils/request"
)

func DouxinCheck(c *gin.Context) {
	sign, signOk := c.GetQuery("sign")
	app, appOk := c.GetQuery("app")

	if signOk && sign == "A1269308-1FC1-4C97-B8F0-6B9BE4387AC2" { // 命令uuidgen随机生成
		if appOk && app == "com.wzc.hudong" {
			var config = map[string]any{
				"crash":    false, // 是否控制app崩溃
				"showGame": true,  // 是否展示游戏
			}
			request.Success(c, config, "成功")
		}
	} else {
		request.Success(c, nil, "成功")
	}
}
