package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/config"
	"github.com/zac-wang/utils/request"
	"strconv"
)

func CommandList(c *gin.Context) {
	//db := adapt.IMSql()
	//var cmd []model.TImCommands
	//if err := db.Find(&cmd).Error; err != nil {
	//	request.Fail(c, []string{}, "发生错误")
	//	return
	//}

	c.Writer.Header().Set("Cache-Control", "public,max-age="+strconv.Itoa(30*24*60*60))
	request.Success(c, config.ImViper.Get("tim-IMCommands"), "")
}
