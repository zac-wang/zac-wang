package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/api/adapt"
	"github.com/zac-wang/utils/request"
	"strings"
)

// 服务器添加 sudo vi /etc/ssh/sshrc : curl https://localhost/api/send_im.php?msg=maolvlv.tk通过ssh登录 -s -o /dev/null

func SendQYWeChatAndTIM(c *gin.Context) {
	msg, ok := c.GetQuery("msg")
	toUser := c.DefaultQuery("toUser", "root")
	cmd := c.DefaultQuery("cmd", "false")
	mType := c.DefaultQuery("type", "QYWeChat|TIM")

	if ok {
		if strings.Contains(mType, "QYWeChat") && cmd != "true" {
			adapt.QiyeIMSend(msg)
		}
		if strings.Contains(mType, "TIM") {
			adapt.TIMSend(msg, cmd == "true", toUser)
		}

		request.Success(c, nil, "发送成功")
	} else {
		request.Fail(c, nil, "参数缺失")
	}
}
