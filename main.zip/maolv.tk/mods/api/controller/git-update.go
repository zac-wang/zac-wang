package controller

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"github.com/zac-wang/api/adapt"
	"github.com/zac-wang/config"
	"github.com/zac-wang/utils/json"
	"github.com/zac-wang/utils/request"
	"os/exec"
)

func sendIM(name string, ref string, gitUrl string, msg string) {
	sendMsg := "git更新: \n<a href='" + gitUrl + "'>" + name + "</a> =&gt; " + ref + "\n( " + msg + " )。"
	//http.Get("https://" + host + "/send_im.php?msg=" + url.QueryEscape(sendMsg))
	adapt.QiyeIMSend(sendMsg)
	adapt.TIMSend(sendMsg, false)
}

func buildAndRestartServer() {
	exec.Command("/bin/bash", "-c", config.ServerViper.GetString("startServerCommand")).Start()
}

func handleGit(fullName string, ref string) (success bool, execMsg string) {
	if fullName == "zac-wang/ZCSystemBin" && ref == "refs/heads/centos" {
		cmd := exec.Command("/bin/bash", "-c", "cd /root/.bash_zc && "+viper.GetString("git.pull"))
		out, err := cmd.CombinedOutput()
		if err != nil {
			return false, err.Error()
		} else {
			return true, string(out)
		}
	} else if fullName == "zac-wang/WebCode" && ref == "refs/heads/maolv.tk" {
		cmd := exec.Command("/bin/bash", "-c", viper.GetString("git.pull"))
		out, err := cmd.CombinedOutput()
		if err != nil {
			return false, err.Error()
		} else {
			//ginServer.Run(":" + config.GetServerPort())
			buildAndRestartServer()
			return true, string(out)
		}
	}
	return false, ""
}

func gitInfo(data map[string]any) (name string, ref string, gitUrl string, msg string) {
	ref = fmt.Sprintf("%s", data["ref"])

	if data["repository"] != nil {
		var repository = data["repository"].(map[string]any)
		name := repository["full_name"]
		gitUrl := repository["url"]
		msg := data["head_commit"].(map[string]any)["message"]

		if name != nil && gitUrl != nil {
			return name.(string), ref, gitUrl.(string), msg.(string)
		}
	} else {
		var repository = data["project"].(map[string]any)
		name := repository["path_with_namespace"]
		gitUrl := repository["web_url"]
		var coms = data["commits"].([]map[string]string)
		msg := coms[0]["message"]

		if name != nil && gitUrl != nil {
			return name.(string), ref, gitUrl.(string), msg
		}
	}
	return "", ref, "", ""
}

func GitUpdate(c *gin.Context) {
	body, _ := c.GetRawData()
	data := json.JsonForByte(body).(map[string]any)
	name, ref, gitUrl, msg := gitInfo(data)

	success, execMsg := handleGit(name, ref)
	result := map[string]any{}
	result["name"] = name
	result["exec"] = execMsg
	result["ref"] = ref

	if success {
		sendIM(name, ref, gitUrl, msg)
		request.Success(c, result, "处理成功")
		//go func() {
		//	time.Sleep(1 * time.Second)
		//	os.Exit(0)
		//}()
	} else {
		request.Fail(c, result, "无法处理")
	}
}
