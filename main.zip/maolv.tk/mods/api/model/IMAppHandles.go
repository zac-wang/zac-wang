package model

import "gorm.io/gorm"

// TIMAppHandles 定义一个模型
type TIMAppHandles struct {
	gorm.Model `json:"-"`

	Name   string `gorm:"index;unique;not null;type:varchar(30);comment:命令名" json:"name"`
	Script string `gorm:"unique;not null;comment:脚本字符串" json:"script"`
}

func (TIMAppHandles) TableName() string {
	return "IMAppHandles"
}
