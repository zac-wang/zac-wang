package model

import (
	"gorm.io/gorm"
)

// create table if not exists IMUsers(ID integer PRIMARY KEY autoincrement, name CHAR(50) NOT NULL UNIQUE, password CHAR(50) NOT NULL, score TEXT);

// TImUsers 定义一个模型
type TImUsers struct {
	gorm.Model

	Name     string `gorm:"index:user;unique;not null;comment:用户名" json:"name"` // 给Name字段创建名为user的索引, 设置用户名（Name）唯一并且不为空
	Password string `gorm:"comment:密码" json:"pwd"`
	Mark     string `gorm:"comment:备注" json:"mark"`
}

func (TImUsers) TableName() string {
	return "IMUsers"
}
