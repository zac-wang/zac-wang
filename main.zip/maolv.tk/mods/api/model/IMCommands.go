package model

import "gorm.io/gorm"

// TImCommands 定义一个模型
type TImCommands struct {
	gorm.Model `json:"-"`

	Desc       string `gorm:"column:desc;index;type:varchar(30);comment:命令名" json:"desc"`
	Script     string `gorm:"column:script;unique;not null;comment:脚本字符串" json:"script"`
	DirectSend bool   `gorm:"column:directSend;default:1;comment:是否直接发送" json:"directSend"`
}

func (TImCommands) TableName() string {
	return "IMCommands"
}
