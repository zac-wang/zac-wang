package api

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/api/controller"
	"github.com/zac-wang/api/middleware"
	"os"
)

func RegisterApiUrl(r *gin.Engine) {
	g := r.Group("api")
	{
		gim := g.Group("im") // im
		{
			// 腾讯IM通知App后台服务器 用户事件
			gim.Any("/serviceCallback", controller.ServiceCallback)
			// 发消息
			gim.GET("/send", controller.SendQYWeChatAndTIM)
			// 登录
			gim.POST("/login", controller.Login)
			// 获取执行命令列表
			gim.GET("/command", middleware.CheckLoginStatus, controller.CommandList)
			// 获取控制app命令列表
			gim.GET("/appHandle", middleware.CheckLoginStatus, controller.AppHandleList)
		}

		g.POST("/git_hooks/git_update.php", controller.GitUpdate) // git钩子，更新本地git仓库
		// iPhone添加订阅日历URL
		g.GET("/my/calender/cal.ics", controller.GetCalenderFile)
		gapp := g.Group("app")
		{
			// 抖心
			gapp.GET("/douxin/check", controller.DouxinCheck)
		}
	}

	r.Any("/", handler)
}

func handler(c *gin.Context) {
	//fmt.Printf("Method: %s\n", c.Request.Method)
	c.String(200, "Hello World")

	query := c.Request.URL.Query()
	if query.Has("pid") {
		c.String(200, " - %d", os.Getpid())
	}
}
