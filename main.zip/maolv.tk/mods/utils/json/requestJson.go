package json

import (
	"bytes"
	"encoding/json"
	"io"
	"os"
)

func JsonForByte(body []byte) any {
	var data any
	err := json.Unmarshal(body, &data)
	if err != nil {
		data = nil
	}
	return data
}

func JsonForReader(reader io.Reader) any {
	body, _ := io.ReadAll(reader)
	return JsonForByte(body)
}

func FormatJson(v any) (b []byte) {
	b, _ = json.MarshalIndent(v, "", "  ")
	return b
}

func PrintFormatJson(str []byte) {
	var out bytes.Buffer
	err := json.Indent(&out, str, "", "\t")
	if err != nil {
		return
	}
	out.WriteTo(os.Stdout)
}
