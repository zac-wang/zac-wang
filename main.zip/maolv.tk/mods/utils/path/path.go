package path

import (
	"io/fs"
	"io/ioutil"
	"os"
	"path/filepath"
	"strings"
)

func GetNowPath() (p string) {
	ex, err := os.Executable()
	if err != nil {
		return ""
	}
	return filepath.Dir(ex)
}

// PathIsExist 检查文件路径是否存在
func PathIsExist(myPath string) (exist bool) {
	if _, err := os.Stat(myPath); os.IsNotExist(err) {
		return false
	}
	return true
}

// CheckDirExistAndCreate 检查文件夹路径 不存在则创建
func CheckDirExistAndCreate(myPath string) error {
	if !PathIsExist(myPath) {
		return os.MkdirAll(myPath, os.ModePerm)
	}
	return nil
}

type GetFilePathsFunc func(path string, info fs.FileInfo, err error) (accord bool, mErr error)

func GetFilePathsIgnoreDirCallBack(p string, info fs.FileInfo, err error) (accord bool, mErr error) {
	if err != nil {
		return false, err
	}
	if info.IsDir() {
		return false, nil
	}
	//if filepath.Ext(path) == ".exe" {
	//	return false, nil
	//}
	for _, s := range strings.Split(p, "/") {
		if strings.HasPrefix(s, ".") {
			return false, nil
		}
	}
	return true, nil
}

// GetAllFilePaths 获取目录文件列表，包括子文件夹文件
func GetAllFilePaths(rootPath string, getFileFun GetFilePathsFunc) ([]string, error) {
	var files []string
	err := filepath.Walk(rootPath, func(p string, info fs.FileInfo, err error) error {
		if getFileFun != nil {
			ok, err := getFileFun(p, info, err)
			if ok {
				files = append(files, p)
			}
			return err
		} else if err != nil {
			files = append(files, p)
		}
		return nil
	})
	return files, err
}

// GetFilePaths 获取目录文件列表，不包括子文件夹文件
func GetFilePaths(rootPath string, getFileFun GetFilePathsFunc) ([]string, error) {
	files, err := ioutil.ReadDir(rootPath)
	if err != nil {
		panic(err)
	}
	var newFiles []string
	for _, fi := range files {
		p := fi.Name()
		if getFileFun != nil {
			if ok, _ := getFileFun(p, fi, nil); ok {
				newFiles = append(newFiles, p)
			}
		} else {
			newFiles = append(newFiles, p)
		}
	}
	return newFiles, nil
}
