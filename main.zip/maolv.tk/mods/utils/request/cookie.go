package request

import (
	"github.com/gin-gonic/gin"
)

func CookieWrite(c *gin.Context, name, value string, maxAge int, e ...any) {
	path := "/"
	domain := c.Request.URL.Host
	secure := false
	httpOnly := true
	switch len(e) {
	case 4:
		httpOnly = e[3].(bool)
		fallthrough
	case 3:
		secure = e[2].(bool)
		fallthrough
	case 2:
		domain = e[1].(string)
		fallthrough
	case 1:
		path = e[0].(string)
	default:
	}
	c.SetCookie(name, value, maxAge, path, domain, secure, httpOnly)
}
