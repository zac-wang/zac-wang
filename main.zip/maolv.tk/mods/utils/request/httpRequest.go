package request

import (
	"bytes"
	"encoding/json"
	"io"
	"io/ioutil"
	"log"
	"net/http"
	"unsafe"
)

// HTTPGet 请求外部http资源
func HTTPGet(url string) (respond []byte) {
	resp, err := http.Get(url)
	if err != nil {
		log.Print(err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	return body
}

// HTTPPost 请求外部http资源
func HTTPPost(url string, data map[string]any) (respond string) {
	bytesData, _ := json.Marshal(data)
	log.Printf("==> url:%s\npost:%s", url, string(bytesData))

	contentType := "application/json;charset=utf-8"
	res, err := http.Post(url, contentType, bytes.NewBuffer([]byte(bytesData)))
	if err != nil {
		log.Print("Fatal error ", err.Error())
		return
	}

	defer res.Body.Close()

	content, err := ioutil.ReadAll(res.Body)
	if err != nil {
		log.Println("Fatal error ", err.Error())
		return
	}

	str := (*string)(unsafe.Pointer(&content)) //转化为string,优化内存
	return *str
}
