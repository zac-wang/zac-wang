package request

import (
	"encoding/json"
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
)

func Respond(c *gin.Context, httpStatus int, code int, data any, msg string, expand ...map[string]any) {
	result := map[string]any{"code": code}
	if data != nil {
		result["data"] = data
	}
	if len(msg) > 0 {
		result["msg"] = msg
	}
	if code >= 200 && code < 300 {
		result["success"] = true
	} else {
		result["success"] = false
	}

	if len(expand) > 0 {
		for k, v := range expand[0] {
			result[k] = v
		}
	}

	c.JSON(httpStatus, result)
	str, _ := json.Marshal(result)
	log.Printf("%s\n%s", c.Request.RequestURI, string(str))
}

func Success(c *gin.Context, data any, msg string, expand ...map[string]any) {
	Respond(c, http.StatusOK, http.StatusOK, data, msg, expand...)
}

func Fail(c *gin.Context, data any, msg string) {
	Respond(c, http.StatusOK, http.StatusBadRequest, data, msg, nil)
}
