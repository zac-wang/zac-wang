package pluginLoad

import (
	myPath "github.com/zac-wang/utils/path"
	"io/fs"
	"os"
	"os/exec"
	"path"
	"plugin"
	"strings"
)

func LoadPlugin(pluginPath string, funcName string) (plugin.Symbol, error) {
	pluginFile, err := plugin.Open(pluginPath)
	if err != nil {
		return nil, err
	}
	targetFunc, err := pluginFile.Lookup(funcName)
	if err != nil {
		return nil, err
	}
	return targetFunc, nil
}

func LoadAllPlugin(pluginDirPath string, funcName string, callback func(plugin.Symbol)) {
	// 编译
	myPath.GetFilePaths(pluginDirPath, func(p string, info fs.FileInfo, err error) (accord bool, mErr error) {
		if info.IsDir() {
			dir := path.Join(pluginDirPath, p)
			file := dir + ".so"
			if myPath.PathIsExist(file) {
				os.Remove(file)
			}

			flag := os.Getenv("CGO_CFLAGS")
			if len(flag) > 0 {
				flag = "-gcflags all=\"-N -l\""
			}
			cmd := "cd " + dir + ";go build -buildmode=plugin " + flag + " -o ../" + p + ".so *.go"
			out, err := exec.Command("/bin/bash", "-c", cmd).CombinedOutput()
			if err == nil {
				println(string(out))
			}
		}
		return false, nil
	})
	// 加载
	myPath.GetFilePaths(pluginDirPath, func(p string, info fs.FileInfo, err error) (accord bool, mErr error) {
		if !info.IsDir() && strings.HasSuffix(p, ".so") {
			symbol, err := LoadPlugin(path.Join(pluginDirPath, p), funcName)
			if err == nil {
				//if hello, ok := symbol.(func()); ok {
				//	hello()
				//}
				callback(symbol)
			}
		}
		return false, nil
	})
}
