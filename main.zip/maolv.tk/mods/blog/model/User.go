package model

import (
	"time"
)

type Users struct {
	//gorm.Model
	ID        uint      `gorm:"primarykey;autoIncrement:10000;autoIncrementIncrement:2"`
	CreatedAt time.Time `json:"omitempty"`
	UpdatedAt time.Time `json:"omitempty"`
	//DeletedAt time.Time `json:"omitempty"`

	User     string `gorm:"unique_index;not null;comment:用户名" json:"user"`
	Phone    string `gorm:"unique;comment:手机号" json:"phone"`
	Email    string `gorm:"comment:邮箱" json:"email"`
	AppleID  string `gorm:"comment:苹果统一登录标识" json:"apple_id"`
	Password string `gorm:"comment:密码" json:"pwd"`
}
