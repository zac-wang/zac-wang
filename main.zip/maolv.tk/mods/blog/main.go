package blog

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/blog/controller"
	"github.com/zac-wang/blog/middleware"
)

func RegisterApiUrl(r *gin.Engine) {
	bDemo := r.Group("/v1/blog")
	{
		uDemo := bDemo.Group("/user")
		{
			uDemo.POST("/login", middleware.ValidFormInfo, controller.Login)
			uDemo.POST("/reg", middleware.ValidFormInfo, controller.Register)
			//uDemo.GET("/all", controller.AllUser)
		}
	}
}
