package controller

import (
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/blog/adapt"
	"github.com/zac-wang/blog/model"
	"github.com/zac-wang/utils/encrypt"
	"github.com/zac-wang/utils/request"
	"gorm.io/gorm"
)

func Login(c *gin.Context) {
	user := c.GetString("user")
	pwd := c.GetString("pwd")

	var u *model.Users
	err := adapt.BlogSql().Where(&model.Users{User: user}).Or(&model.Users{Phone: user}).Or(&model.Users{Email: user}).First(&u).Error
	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			request.Fail(c, nil, "用户名不存在")
		}
		request.Fail(c, nil, err.Error())
		return
	} else if u.Password != pwd {
		request.Fail(c, nil, "密码错误")
		return
	}

	token := encrypt.AesEncrypt(user, adapt.CryptKey())
	if len(token) > 0 {
		request.CookieWrite(c, "token", string(token), 24*60*60)
		request.Success(c, gin.H{"user": user}, "登录成功")
		return
	}
	request.Fail(c, gin.H{"user": user}, "登录失败")
}
