package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/blog/adapt"
	"github.com/zac-wang/blog/model"
	"github.com/zac-wang/utils/request"
)

func Register(c *gin.Context) {
	user := c.GetString("user")
	phone := c.GetString("phone")
	pwd := c.GetString("pwd")
	/*
	   	var res string
	   	err := adapt.BlogSql().Raw(`
	   select case
	     when exists (SELECT * FROM users where user = ?)
	       then JSON_OBJECT('msg', '用户名已存在', 'type', '1')
	     when exists (SELECT * FROM users where phone = ?)
	       then JSON_OBJECT('msg', '手机号已存在', 'type', '2')
	     else
	       JSON_OBJECT('msg', '可以注册', 'type', '0')
	   end
	   `, user, phone).Scan(&res).Error

	   	if err != nil {
	   		request.Fail(c, nil, err.Error())
	   		return
	   	}
	   	result := json.JsonForByte([]byte(res)).(map[string]any)
	   	if result["type"].(string) != "0" {
	   		request.Fail(c, nil, result["msg"].(string))
	   		return
	   	}
	*/
	cErr := adapt.BlogSql().Create(&model.Users{
		User:     user,
		Phone:    phone,
		Password: pwd,
	}).Error
	if cErr != nil {
		request.Fail(c, gin.H{"user": user}, cErr.Error())
		return
	}
	request.Success(c, gin.H{"user": user}, "注册成功")
}
