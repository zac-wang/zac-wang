package controller

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/blog/adapt"
	"github.com/zac-wang/utils/request"
)

// AllUser 使用sql语句查询所有用户，直接返回json
func AllUser(c *gin.Context) {
	var result []map[string]any

	// mysql语句
	// mysql不支持SQLServer语句："select * from users for json auto;"
	err := adapt.BlogSql().Raw("SELECT id, user, phone from users;").Scan(&result).Error

	if err == nil {
		request.Fail(c, result, "")
		return
	}
	request.Fail(c, nil, "无数据")
}
