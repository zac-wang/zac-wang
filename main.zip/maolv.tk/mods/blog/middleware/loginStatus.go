package middleware

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/blog/adapt"
	"github.com/zac-wang/utils/request"
	"net/http"
	"strings"
)

// ValidFormInfo 校验登录字段信息
func ValidFormInfo(c *gin.Context) {
	user := c.DefaultPostForm("user", "")
	phone := c.DefaultPostForm("phone", "")
	pwd := c.DefaultPostForm("password", "")
	c.Set("user", user)
	c.Set("phone", phone)
	c.Set("pwd", pwd)

	if b, msg := adapt.ValidUserName(user); !b {
		request.Fail(c, nil, msg)
		c.Abort()
		return
	} else if b, msg := adapt.ValidPhone(phone); strings.HasSuffix(c.Request.URL.Path, "/reg") && !b {
		// 注册时手机号不能为空
		request.Fail(c, nil, msg)
		c.Abort()
		return
	} else if b, msg := adapt.ValidPassword(pwd); !b {
		request.Fail(c, nil, msg)
		c.Abort()
		return
	}
	c.Next()
}

// CheckLoginStatus 校验当前登录状态
func CheckLoginStatus(c *gin.Context) {
	if adapt.IsLogin(c) {
		c.Next()
	} else {
		request.Respond(c, http.StatusUnauthorized, http.StatusUnauthorized, nil, "未授权")
		c.Abort()
	}
}
