package adapt

import (
	"errors"
	"fmt"
	"github.com/zac-wang/blog/model"
	"github.com/zac-wang/config"
	"gorm.io/driver/mysql"
	"gorm.io/gorm"
	"time"
)

var blogSql *gorm.DB

func BlogSql() *gorm.DB {
	if blogSql == nil {
		blogSql = getBlogSql()
	}
	return blogSql
}

func getBlogSql() *gorm.DB {
	username := config.SqlViper.GetString("user")
	password := config.SqlViper.GetString("pwd")
	host := config.SqlViper.GetString("host")
	port := config.SqlViper.GetInt("port")
	dbName := config.SqlViper.GetString("dbName.blog")
	timeout := config.SqlViper.GetString("timeout")

	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8&parseTime=True&loc=Local&timeout=%s", username, password, host, port, dbName, timeout)
	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{
		SkipDefaultTransaction: true,
	})
	if err != nil {
		panic(errors.New("连接数据库失败"))
	}

	db = db.Set("gorm:table_options", "ENGINE=InnoDB DEFAULT CHARSET=utf8")

	sqlDB, _ := db.DB()
	sqlDB.SetMaxOpenConns(100)                 // 设置数据库连接池最大连接数
	sqlDB.SetMaxIdleConns(20)                  // 设置最大允许的闲置连接数
	sqlDB.SetConnMaxLifetime(time.Hour)        // 设置连接可复用的最大时间,最大生存时间建议一定要小于wait_timeout/2 ，(mysql> show variables like 'wait_timeout';)
	sqlDB.SetConnMaxIdleTime(10 * time.Minute) // 设置连接最大闲置时间，超出将被释放

	initTables(db)

	return db
}

// / 注册数据库表
func initTables(db *gorm.DB) {
	err := db.AutoMigrate(
		model.Users{},
	)
	if err != nil {
		println(err)
	}
}
