package adapt

import (
	"errors"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"github.com/zac-wang/blog/model"
	"github.com/zac-wang/utils/encrypt"
	"gorm.io/gorm"
	"regexp"
)

func ValidUserName(user string) (b bool, msg string) {
	if len(user) < 4 || len(user) > 15 {
		return false, "用户名错误"
	}
	return true, ""
}

func ValidPhone(phone string) (b bool, msg string) {
	if len(phone) != 11 {
		return false, "手机号错误"
	}
	regRuler := "^1[345789]{1}\\d{9}$"
	reg := regexp.MustCompile(regRuler)
	b = reg.MatchString(phone)
	if !b {
		return false, "手机号格式错误"
	}
	return true, ""
}

func ValidPassword(pwd string) (b bool, msg string) {
	if len(pwd) < 5 || len(pwd) > 28 {
		return false, "密码错误"
	}
	return true, ""
}

// CryptKey token加密key
func CryptKey() string {
	return viper.GetString("blog.encrypt-aes")
}

func IsLogin(c *gin.Context) (isLogin bool) {
	token, _ := c.Cookie("token")
	user := encrypt.AesDecrypt(token, CryptKey())
	if len(user) > 0 {
		var u *model.Users
		err := BlogSql().Where(&model.Users{User: string(user)}).First(&u).Error
		if !errors.Is(err, gorm.ErrRecordNotFound) {
			return true
		}
	}
	return false
}
