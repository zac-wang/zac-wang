package config

import (
	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
	"log"
	"os"
	"path"
)

var ServerViper *viper.Viper = getNewViper("server.yaml")
var SqlViper *viper.Viper = getNewViper("sql.yaml")
var ImViper *viper.Viper = getNewViper("im.yaml")

func getNewViper(configName string) *viper.Viper {
	workDir, _ := os.Getwd()

	myViper := viper.New()
	myViper.SetConfigName(configName)
	myViper.SetConfigType("yaml")
	myViper.AddConfigPath(path.Join(workDir, "./tmp/config/"))
	myViper.AddConfigPath(path.Join(workDir, "/resources/config/"))
	err := myViper.ReadInConfig()
	if err != nil {
		log.Printf("读取配置失败，err:%v\n", err)
		panic(err)
	}
	return myViper
}

var Conf = new(AppConfig)

func init() {
	setupViper()
}

func setupViper() {
	workDir, _ := os.Getwd()

	//viper.SetConfigFile(path.Join(workDir, "/resources/config/application.yaml"))
	viper.SetConfigName("application.yaml")
	viper.SetConfigType("yaml")
	viper.AddConfigPath(path.Join(workDir, "./tmp/config/"))
	viper.AddConfigPath(path.Join(workDir, "/resources/config/"))
	err := viper.ReadInConfig()
	if err != nil {
		log.Printf("读取配置失败，err:%v\n", err)
		panic(err)
	}

	viper.Unmarshal(Conf)
	if err != nil {
		log.Printf("读取配置失败，err:%v\n", err)
		panic(err)
	}

	viper.OnConfigChange(func(in fsnotify.Event) {
		log.Println("配置文件发生变化！")
		if err := viper.Unmarshal(Conf); err != nil {
			log.Printf("读取配置失败，err:%v\n", err)
		}
	})
	viper.WatchConfig()
}

type AppConfig struct {
	Name string `mapstructure:"name"`
	Port int    `mapstructure:"port"`

	*Log `mapstructure:"log"`
}

type Log struct {
	Path string `mapstructure:"path"`
}
