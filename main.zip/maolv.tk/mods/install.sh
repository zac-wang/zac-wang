#!/bin/bash

modsPath=$(pwd)


addMod() {
  projectPath=$1
  modPath=$2

  cd $modPath
  [ ! -f $modPath/go.mod ] && go mod init github.com/zac-wang/$(basename $modPath) #初始化go包
  go mod tidy

  # 缩短modPath，计算相对路径
  if [[ "$modPath" = "$projectPath"* ]]; then
    projectPathLen=${#projectPath}
    modPath=.${modPath:$projectPathLen}
  fi

  cd $projectPath
  go mod edit -replace github.com/zac-wang/$(basename $modPath)=$modPath # 本地发布/重定向
}



ls $modsPath | while read row; do
  if [ -d $modsPath/$row ]; then
    addMod $(dirname $modsPath) $modsPath/$row
  fi
done

go mod tidy

