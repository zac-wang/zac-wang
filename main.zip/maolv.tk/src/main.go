package main

import (
	"github.com/zac-wang/config"
	myPath "github.com/zac-wang/utils/path"
	"github.com/zac-wang/utils/pluginLoad"
	"log"
	"os"
	"path"
	"plugin"
	"server/src/router"
)

func init() {
	pluginLoad.LoadAllPlugin("plugins", "Hello", func(symbol plugin.Symbol) {
		if hello, ok := symbol.(func()); ok {
			hello()
		}
	})
}

func main() {
	setupLog()

	router.StartServer()
}

func setupLog() {
	logPath := config.ServerViper.GetString("log-path")
	myPath.CheckDirExistAndCreate(path.Dir(logPath))
	logFile, err := os.OpenFile(logPath, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0644)
	if err != nil {
		return
	}
	log.SetOutput(logFile)
	log.SetFlags(log.Llongfile | log.Lmicroseconds | log.Ldate)
}
