package router

import (
	"github.com/gin-gonic/gin"
	"log"
	"net/http"
)

// StaticMiddle 注册全局中间件
func StaticMiddle(c *gin.Context) {
	log.Printf("============= 新请求：%s\n", c.Request.RequestURI)
	//c.Abort()
	c.Next()
}

// Cors 跨域
func Cors(c *gin.Context) {
	c.Writer.Header().Set("Access-Control-Allow-Origin", "*")
	c.Writer.Header().Set("Access-Control-Allow-Credentials", "true")
	c.Writer.Header().Set("Access-Control-Allow-Headers", "DNT,X-Mx-ReqToken,Keep-Alive,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Authorization")
	c.Writer.Header().Set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, TRACE, CONNECT, OPTIONS")

	//如果是跨域预检请求，那就不再继续执行
	if c.Request.Method == "OPTIONS" {
		c.Abort()
		c.Writer.WriteHeader(http.StatusOK)
	} else {
		c.Next()
	}
}

func RegisterMiddle(r *gin.Engine) {
	r.Use(StaticMiddle)
	r.Use(Cors)
}
