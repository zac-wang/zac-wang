package router

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/api"
	"github.com/zac-wang/blog"
	"github.com/zac-wang/config"
	"github.com/zac-wang/demo"
	"github.com/zac-wang/ginServer"
	"os/exec"
	"strings"
)

func StartServer() {
	RegisterMiddle(ginServer.GinEngine)
	api.RegisterApiUrl(ginServer.GinEngine)
	blog.RegisterApiUrl(ginServer.GinEngine)
	demo.RegisterApiUrl(ginServer.GinEngine)
	RegisterSource(ginServer.GinEngine)

	startServer()
}

func startServer() {
	port := config.ServerViper.GetString("port")
	println("服务器启动，端口：" + port)
	killOldServer(port)

	//f, _ := os.Create("gin.log")
	//gin.DefaultWriter = io.MultiWriter(f, os.Stdout)
	gin.SetMode(config.ServerViper.GetString("mode"))
	if port == "443" {
		sslConfig := config.ServerViper
		ginServer.GinEngine.RunTLS(":"+port, sslConfig.GetString("sslCert"), sslConfig.GetString("sslKey"))
	} else {
		ginServer.GinEngine.Run(":" + port)
	}
	//ginServer.Run(":" + port)
}

// 检查端口占用，杀掉占用端口的(旧)进程
func killOldServer(port string) {
	killServerCommand := strings.ReplaceAll(config.ServerViper.GetString("killServerCommand"), "${port}", port)
	cmd := exec.Command("/bin/bash", "-c", killServerCommand)
	_, err := cmd.CombinedOutput()
	if err != nil {
		fmt.Printf("%s\n请手动检查端口是否已被占用：netstat -nlp | grep :18080 | awk '{print $7}' | awk -F\"/\" '{print $1}'\n", err.Error())
	}
}
