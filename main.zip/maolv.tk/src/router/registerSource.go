package router

import (
	"github.com/gin-gonic/gin"
	"github.com/zac-wang/blog/adapt"
	"github.com/zac-wang/config"
	"github.com/zac-wang/utils/path"
	"html/template"
	"net/http"
	"strings"
)

func RegisterSource(r *gin.Engine) {
	registerHtml(r)
	registerSourceReflectUrl(r)
	registerDefault(r)
}

// 加载html模板
func registerHtml(r *gin.Engine) {
	setHtmlTemplateFunc(r)

	// 一、加载html文件
	//r.LoadHTMLFiles(config.ServerViper.GetString("htmlTemplate")+"/index.html")
	r.LoadHTMLGlob(config.ServerViper.GetString("htmlTemplate") + "/**/*")
	r.Any("/index.html", func(c *gin.Context) {
		c.HTML(http.StatusOK, "origin.html", gin.H{"title": "index", "text": "首页"})
	})
}

// 自定义函数，将传入的字符串解析为网页内容
func setHtmlTemplateFunc(r *gin.Engine) {
	r.SetFuncMap(template.FuncMap{
		"stringUpper": func(str string) template.HTML {
			return template.HTML(strings.ToUpper(str))
		},
	})
}

// 设置url与本地资源映射关系
func registerSourceReflectUrl(r *gin.Engine) {
	urlMaps := config.ServerViper.GetStringMapString("staticFileMaps")
	for url, dirPath := range urlMaps {
		if len(dirPath) > 0 && path.CheckDirExistAndCreate(dirPath) == nil {
			r.Static(url, dirPath)
		}
	}

	// 将指定链接指向到本地目录
	//r.StaticFS("h5", http.Dir("resources/www/h5"))

	// 单个文件
	//r.StaticFile("h5/index.html", "resources/www/h5/index.html")
}

// 处理未知url
func registerDefault(r *gin.Engine) {
	// 二、重定向
	r.NoRoute(func(c *gin.Context) {
		toUrl := "/public/404/"
		if strings.HasPrefix(c.Request.URL.Path, "/api") {
			c.JSON(200, gin.H{"msg": "URL错误"})
			return
		} else if strings.HasPrefix(c.Request.URL.Path, "/h5/blog/") {
			if adapt.IsLogin(c) {
				toUrl = "/h5/blog/index.html"
			} else {
				toUrl = "/h5/blog/account/login.html"
			}

			// HTTP重定向
			c.Redirect(http.StatusMovedPermanently, toUrl)
			return
		}

		// 路由重定向
		if c.Request.URL.Path != toUrl {
			c.Request.URL.Path = toUrl
			c.Request.Method = http.MethodGet
			r.HandleContext(c)
		} else {
			println("404页面丢失，请检查本地404页面路径")
		}
	})
}
