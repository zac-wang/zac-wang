package main

func Hello() {
	println("hello word!!!")
}
