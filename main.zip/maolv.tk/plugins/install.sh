#!/bin/bash

cd TestPlugin

dirName=$(basename $(pwd))
[ -f ../$dirName.so ] && rm -f ../$dirName.so

go build -buildmode=plugin -o ../$dirName.so *.go
#go build -buildmode=plugin -gcflags all="-N -l" -o ../$dirName.so *.go # 调试使用版本