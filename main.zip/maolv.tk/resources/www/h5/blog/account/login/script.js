console.clear();

const showLoginBtn = document.getElementById('showLogin');
const showSignupBtn = document.getElementById('showSignup');

showLoginBtn.addEventListener('click', (e) => {
    let parent = e.target.parentNode.parentNode;
    Array.from(e.target.parentNode.parentNode.classList).find((element) => {
        if(element !== "slide-up") {
            parent.classList.add('slide-up')
        }else{
            showSignupBtn.parentNode.classList.add('slide-up')
            parent.classList.remove('slide-up')
        }
    });
});

showSignupBtn.addEventListener('click', (e) => {
    let parent = e.target.parentNode;
    Array.from(e.target.parentNode.classList).find((element) => {
        if(element !== "slide-up") {
            parent.classList.add('slide-up')
        }else{
            showLoginBtn.parentNode.parentNode.classList.add('slide-up')
            parent.classList.remove('slide-up')
        }
    });
});


const loginBtn = document.getElementById('login');
const signupBtn = document.getElementById('signup');

loginBtn.addEventListener('click', (e) => {
    $.post("/v1/blog/user/login",$('.login .form-holder').serializeArray(),function(data,status){
        if (data.code == 200) {
            alert("登录成功")
        } else {
            alert(data.msg)
        }
    },'json');
});

signupBtn.addEventListener('click', (e) => {
    $.post("/v1/blog/user/reg",$('.signup .form-holder').serializeArray(),function(data,status){
        if (data.code == 200) {
            alert("注册成功")
        } else {
            alert(data.msg)
        }
    },'json');
});
